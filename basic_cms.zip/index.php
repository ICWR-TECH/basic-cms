<?php
error_reporting(0);
include "admin/config.php";

date_default_timezone_set('Asia/Jakarta');
$waktu_visit=date("Y-m-d H:i:s");
$uri=htmlentities($_SERVER['REQUEST_URI']);
$user_agent=htmlentities($_SERVER['HTTP_USER_AGENT']);
$ip=$_SERVER['REMOTE_ADDR'];
mysqli_query($conn,"INSERT INTO visitor_index(url,tanggal,user_agent,ip) values('$uri','$waktu_visit','$user_agent','$ip')");
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <title>WebsiteKu!</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="asset/bootstrap/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css">
  <style>
  .gal {
  	-webkit-column-count: 4; /* Chrome, Safari, Opera */
      -moz-column-count: 4; /* Firefox */
      column-count: 4;
  }
  .gal img{
  	width: 100%; padding: 7px 0;
  }

  @media (max-width: 768px) {
  	.gal {
  		-webkit-column-count: 2; /* Chrome, Safari, Opera */
  		-moz-column-count: 2; /* Firefox */
  		column-count: 2;
  	}
  }

  @media (max-width: 500px) {
  	.gal {
  		-webkit-column-count: 1; /* Chrome, Safari, Opera */
  		-moz-column-count: 1; /* Firefox */
  		column-count: 1;
  	}
  }
  .cp{
        color:white;
        opacity: 0.5;
        text-align: center;
  }
  </style>

</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
          data-target="#asd" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a href="index.php" class="navbar-brand page-scroll"><span class="glyphicon glyphicon-home"> Home</span></a>
      </div>
      <div class="collapse navbar-collapse" id="asd">
        <ul class="nav navbar-nav navbar">
          <li class="dropdown">
            <a class="dropdown-toggle" href="index.php?berita=1">Berita</a>
          </li>
          <li class="dropdown">
            <a class="dropdown-toggle" href="?gallery=1">Gallery</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <br><br><br><br>
  <?php 
  if(!$_GET){
  ?>
    <center>
					<img src="asd.jpeg" alt="#" width="50%">
    </center>
  <?php
  }
  ?>
  <div class="container">
    <?php
    if($_GET['berita']){
    $batas   = 6;
    $halaman = $_GET['berita'];
        if(empty($halaman)){
            $posisi  = 0;
            $halaman = 1;
        }
        else{
            $posisi  = ($halaman-1) * $batas;
        }

    $no = $posisi+1;
    $sql="SELECT * from berita order by id desc limit $posisi,$batas";
    $hasil=mysqli_query($conn,$sql);
    ?>
		<div class="text-center">
				<h1>Berita</h1>
		</div>
        <br>
        <?php while($asd=mysqli_fetch_array($hasil)){ ?>
		<div class="col-sm-6">
			<div class="thumbnail">
            <h3 class="text-center"><?php echo $asd['judul']; ?></h3><br>
				<img src="berita/<?php echo str_replace('+',' ',urlencode(mysqli_real_escape_string($conn,$asd['file']))); ?>" alt="Gambar">
				<div class="caption">
					<p><?php echo substr($asd['isi'],0,50); ?></p>
          <p><b>Konten: </b><?php echo $asd['konten']; ?></p>
          <p><b>Waktu upload: </b><?php echo $asd['tanggal']; ?></p>
					<p><a href="?view=berita&id=<?php echo $asd['id'] ?>" class="btn btn-primary" role="button">View</a></p>
				</div>
			</div>
		</div>
    <?php
        }
    ?>
    <?php

    $query2     = mysqli_query($conn, "select * from berita");
    $jmldata    = mysqli_num_rows($query2);
    $jmlhalaman = ceil($jmldata/$batas);
    ?>
    <div class="text-center">
        <ul class="pagination">
            <?php
            for($i=1;$i<=$jmlhalaman;$i++) {
                if ($i != $halaman) {
                    echo "<li class='page-item'><a class='page-link' href='index.php?berita=$i'>$i</a></li>";
                } else {
                    echo "<li class='page-item active'><a class='page-link' href='#'>$i</a></li>";
                }
            }
            ?>
        </ul>
    </div>

    <?php
    }if($_GET['view']=="berita"){
        if($_GET['id']){
            $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
            $q=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM berita where id='$id'"));
        ?>
        <div class="container">	
          <div class="col-md-12" style="padding: 0">
            <ol class="breadcrumb">
              <li><a href="index.php">Home</a></li>
              <li><a href="#"><?php echo $q['konten']; ?></a></li>
              <li class="active"><?php echo $q['judul']; ?></li>
            </ol>
          </div>

          <div class="col-md-12" style="padding: 0">
            <h2 style="margin-top: 0" class="text-center"><? echo $q['judul']; ?></h2>
            <br>
            <div class="thumbnail">
              <img src="berita/<?php echo str_replace('+',' ',urlencode(mysqli_real_escape_string($conn,$q['file']))); ?>">
            </div>
            <? echo $q['isi']; 
            $q_real=mysqli_query($conn,"SELECT * FROM berita order by id DESC");
            ?>
            <br>
            <p><b>Tanggal upload: </b><? echo $q['tanggal'] ?></p>
            <p><b>Author konten: </b><? echo $q['author']; ?></p>
          </div>
        </div>
        <div class="clearfix"></div>

        <?php
        }else{
            echo '
            <div class="alert alert-warning">Id tak diketahui!</div>
            <script>
            setTimeout(
                  function(){
                    window.location = "?berita=1"
                  },
                  2000);
      
            </script>
            ';
        }
    }elseif($_GET['gallery']){
      $batas   = 21;
      $halaman = $_GET['gallery'];
          if(empty($halaman)){
              $posisi  = 0;
              $halaman = 1;
          }
          else{
              $posisi  = ($halaman-1) * $batas;
          }
  
      $no = $posisi+1;
      $sql="SELECT * from gallery order by id desc limit $posisi,$batas";
      $hasil=mysqli_query($conn,$sql);
      ?>
          <!-- membuat jumbotron -->
      <div class="text-center">
          <h1>Gallery</h1>
      </div>
          <br>
      <!-- akhir jumbotron -->
          <?php while($asd=mysqli_fetch_array($hasil)){ ?>
        <div class="thumbnail">
          <a href="?lihat=gallery&id=<?php echo $asd['id']; ?>">
          <img src="gallery/<?php echo str_replace('+',' ',urlencode(mysqli_real_escape_string($conn,$asd['gambar']))); ?>" alt="Gambar" height="200px">
          </a>
        </div>
      <?php
          }
      ?>
      <?php
  
      $query2     = mysqli_query($conn, "SELECT * from gallery");
      $jmldata    = mysqli_num_rows($query2);
      $jmlhalaman = ceil($jmldata/$batas);
      ?>
      <div class="text-center">
          <ul class="pagination">
              <?php
              for($i=1;$i<=$jmlhalaman;$i++) {
                  if ($i != $halaman) {
                      echo "<li class='page-item'><a class='page-link' href='index.php?gallery=$i'>$i</a></li>";
                  } else {
                      echo "<li class='page-item active'><a class='page-link' href='#'>$i</a></li>";
                  }
              }
              ?>
          </ul>
      </div>
      <?php 
      }elseif($_GET['lihat']=="gallery"){
        $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
        if($_GET['id']){
          $q=mysqli_query($conn,"SELECT * FROM gallery where id='$id'");
          $q_tampil=mysqli_fetch_array($q);
        ?>
        <h1>Informasi foto</h1>
        <div class="row">
          <div class="col-md-8">
            <img src="gallery/<?php echo str_replace('+',' ',urlencode(mysqli_real_escape_string($conn,$q_tampil['gambar']))); ?>" class="img-responsive">
          </div>
          <div class="col-md-4">
            <table class="table">
              <tr>
                <th width="120">Judul gambar</th>
                <td><?php echo $q_tampil['judul']; ?></td>
              </tr>
              <tr>
                <th>Deskripsi</th>
                <td><?php echo $q_tampil['isi']; ?></td>
              </tr>
              <tr>
                <th>Tanggal upload</th>
                <td><?php echo $q_tampil['tanggal']; ?></td>
              </tr>
              <tr>
                <td colspan="2"><a target="_blank" href="gallery/<? echo str_replace('+',' ',urlencode(mysqli_real_escape_string($conn,$q_tampil['gambar']))); ?>" class="btn btn-primary btn-block">Lihat detail</a></td>
              </tr>
            </table>
          </div>
        </div>
        <br><br><br><br><br><br>
        <?php
        }else{
          echo '
          <div class="alert alert-warning">Id tak diketahui!</div>
          <script>
          setTimeout(
                function(){
                  window.location = "?gallery=1"
                },
                2000);
    
          </script>
          ';
        }
      }
      ?>
  </div>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <footer>
  <br>
  <h4 class="cp">Copyright &copy ICWR-TECH 2020</h4>
  </footer>
  </body>

<script src="asset/bootstrap/js/jquery-3.1.1.min.js"></script>
<script src="asset/bootstrap/js/jquery.easing.1.3.js"></script>
<script src="asset/bootstrap/js/bootstrap.min.js"></script>
<script src="asset/bootstrap/js/script.js"></script>
</html>
