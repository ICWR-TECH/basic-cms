<?php
error_reporting(0);
session_start();
include "config.php";
if(!$_SESSION['admin']){
    header("location:index.php");
    exit;
}
if($_GET['m']=="out"){
    session_destroy();
    header("location:index.php");
    exit;
}
date_default_timezone_set('Asia/Jakarta');
$waktu_visit=date("Y-m-d H:i:s");
$uri=$_SERVER['REQUEST_URI'];
$user_agent=$_SERVER['HTTP_USER_AGENT'];
$ip=$_SERVER['REMOTE_ADDR'];
mysqli_query($conn,"INSERT INTO visitor(url,tanggal,user_agent,ip) values('$uri','$waktu_visit','$user_agent','$ip')");
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <!-- <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content=""> -->

  <title>Admin!</title>

  <!-- Custom fonts for this template-->
  <link href="../asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../asset/css/sb-admin-2.min.css" rel="stylesheet">
  <script type="text/javascript" src="../asset/ckeditor/ckeditor.js"></script>
  <script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dash.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Admin</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="dash.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">


      <!-- Heading -->
      <div class="sidebar-heading">
        Addons
      </div>

      <!-- Nav Item - Charts -->
      <li class="nav-item">
        <a class="nav-link" href="?menu=tambah_gallery">
          <span>Tambah gallery</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?menu=lihat_gallery">
          <span>Lihat gallery</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?menu=tambah_berita">
          <span>Tambah Berita</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?menu=lihat_berita">
          <span>Lihat berita</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?menu=lihat_user">
          <span>Lihat User</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
 
            <div class="topbar-divider d-none d-sm-block"></div>
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="fas fa-info-circle">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                </span>
                </span>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="?m=out" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <?php
          if(!$_GET){
          $cokk=mysqli_query($conn,"SELECT * FROM visitor");
          while($asda=mysqli_fetch_array($cokk)){
            $cont=$i++;
          }
          $suuu=mysqli_query($conn,"SELECT * FROM visitor_index");
          while($asuuu=mysqli_fetch_array($suuu)){
            $cont1=$a++;
          }
          ?>
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          </div>
          <img src="../asd.jpeg" alt="..." height="900px" width="100%">
          <br><br><br>
          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-6 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Visitor Dashboard admin</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      <?php
                                echo $cont++;
                      ?></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-6 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Visitor Halaman Depan</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $cont1++; ?></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#tambahuser">Tambah user</button>
          <div class="modal fade" id="tambahuser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Tambah user</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form class="form-group" action="dash.php" method="post">
                    <label for="t_user">Username</label>
                    <input type="text" name="t_user" id="t_user" class="form-control" placeholder="Username..."><br>
                    <label for="t_pass">Password</label>
                    <input type="password" name="t_pass" id="t_pass" class="form-control" placeholder="Password...">
                    <br>
                    <input type="submit" name="t_submit" value="Submit" class="btn btn-primary">
                  </form>
                </div>
                <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
          </div>
          <br><br><br>
          <?php
            $t_user=mysqli_real_escape_string($conn,$_POST['t_user']);
            $t_pass=md5(mysqli_real_escape_string($conn,$_POST['t_pass']));
            $q="INSERT INTO admine(username,password) values('$t_user','$t_pass')";
            if($_POST['t_submit']){
              if(mysqli_query($conn,$q)){
                echo "<br><br><br><div class='alert alert-success'>Success tambah user!</div>";
              }else{
                echo "<div class='alert alert-danger'>Cek config!</div>";
              }
            }
          }
          if($_GET['menu']=="tambah_gallery"){
          ?>
            <h1>Tambah gallery</h1>
            <form action="?menu=tambah_gallery" method="post" class="form-group" enctype="multipart/form-data">
              <label for="judul">Judul</label>
              <input type="text" name="judul" id="judul" placeholder="Judul..." class="form-control">
              <br>
              <label for="gambar">Gambar Title</label><br>
              <input type="file" name="file" id="gambar" class="">
              <br><br>
              <label for="isi">Isi</label>
              <textarea class="ckeditor" name="isi" id="ckedtor" alt></textarea>
              <br>
              <input type="submit" name="submit" value="submit" class="btn btn-primary">
            </form>
          <?php
          $judul=htmlentities(mysqli_real_escape_string($conn,$_POST['judul']));
          $isi=mysqli_real_escape_string($conn,$_POST['isi']);
          $tanggal=date("Y-m-d H:i:s");
          $rep_isi=str_replace("alert","",$isi);
          //end
          $nama_g=mysqli_real_escape_string($conn,$_FILES['file']['name']);
          $type_g=$_FILES['file']['type'];
          $ukuran_g=$_FILES['file']['size'];
          $tmp_g=$_FILES['file']['tmp_name'];
          $tempat_g="../gallery/".$nama_g;
          $target_file_g="berita/".basename($nama_g);
          $type_file_g=pathinfo($target_file_g,PATHINFO_EXTENSION);
          if($_POST['submit']){
            if($type_file_g=="jpeg"||$type_file_g=="jpg"||$type_file_g=="gif"||$type_file_g=="png"||$type_file_g=="JPEG"||$type_file_g=="JPG"||$type_file_g=="GIF"||$type_file_g=="PNG"){
              if($ukuran_g<2097152){
                if(move_uploaded_file($tmp_g,$tempat_g)){
                  if(mysqli_query($conn,"INSERT INTO gallery(judul,gambar,isi,tanggal) values('$judul','$nama_g','$rep_isi','$tanggal')")){
                    echo "<div class='alert alert-success'>Success!</div>";
                  }else{
                    echo "<div class='alert alert-danger'>Cek config!</div>";
                  }
                }else{
                  echo "<div class='alert alert-danger'>Gagal terupload!</div>";
                }
              }else{
                echo "<div class='alert alert-danger'>Compres gambar dulu!</div>";
              }
            }else{
              echo "<div class='alert alert-danger'>Harap lihat file!</div>";
            }
          }
          }elseif ($_GET["menu"]=="lihat_gallery") {
            echo "<h1>Lihat gallery</h1>";
            $no=1;
            $q=mysqli_query($conn,"SELECT * FROM gallery order by id DESC");
          ?>
          <table class="table table-boarded">
            <thead>
              <tr>
                <th width="70px">No</th>
                <th width="350px">Judul</th>
                <th>Isi</th>
                <th width="200px">Setting</th>
              </tr>
            </thead>
            <tbody>
              <?php
              while($cok=mysqli_fetch_array($q)){
              ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $cok['judul']; ?></td>
                <td><?php echo $cok['isi']; ?></td>
                <td><a href="?menu=edit_gallery&id=<?php echo $cok['id']; ?>" class="btn btn-warning">Edit</a> <a href="?menu=lihat_gallery&delet=delete_gallery&id=<?php echo $cok['id']; ?>" class="btn btn-danger">Delete</a></td>
              </tr>
              <?php
              }
              ?>
            </tbody>
          </table>
          <?php
          if($_GET['delet']=="delete_gallery"){
            if($_GET['id']){
              $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
              $q="DELETE FROM gallery where id='$id'";
              if(mysqli_query($conn,$q)){
                echo "<div class='alert alert-success'>Success!</div>
                <script>
                setTimeout(
                      function(){
                        window.location = '?menu=lihat_gallery'
                      },
                      2000);
          
                      </script>
                ";
              }else{
                echo "<div class='alert alert-danger'>Cek config!</div>";
              }
            }else{
              echo "<div class='alert alert-warning'>Id tak ditemukan</div>";
            }
          }
          }elseif($_GET['menu']=="edit_gallery"){
            $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
          ?>
          <h1>Edit gallery</h1>
          <form action="?menu=edit_gallery&id=<?php echo $id; ?>" method="post" class="form-group" enctype="multipart/form-data">
              <label for="judul">Judul</label>
              <input type="text" name="judul" id="judul" placeholder="Judul..." class="form-control">
              <br>
              <label for="gambar">Gambar Title</label><br>
              <input type="file" name="file" id="gambar" class="">
              <br><br>
              <label for="isi">Isi</label>
              <textarea class="ckeditor" name="isi" id="ckedtor" alt></textarea>
              <br>
              <input type="submit" name="submit" value="submit" class="btn btn-primary">
          </form>
          <?php
          $judul=htmlentities(mysqli_real_escape_string($conn,$_POST['judul']));
          $isi=mysqli_real_escape_string($conn,$_POST['isi']);
          $tanggal=date("Y-m-d H:i:s");
          $rep_isi=str_replace("alert","",$isi);
          //end
          $nama_g=mysqli_real_escape_string($conn,$_FILES['file']['name']);
          $type_g=$_FILES['file']['type'];
          $ukuran_g=$_FILES['file']['size'];
          $tmp_g=$_FILES['file']['tmp_name'];
          $tempat_g="../gallery/".$nama_g;
          $target_file_g="berita/".basename($nama_g);
          $type_file_g=pathinfo($target_file_g,PATHINFO_EXTENSION);
          if($_POST['submit']){
            if($type_file_g=="jpeg"||$type_file_g=="jpg"||$type_file_g=="gif"||$type_file_g=="png"||$type_file_g=="JPEG"||$type_file_g=="JPG"||$type_file_g=="GIF"||$type_file_g=="PNG"){
              if($ukuran_g<2097152){
                if(move_uploaded_file($tmp_g,$tempat_g)){
                  if(mysqli_query($conn,"UPDATE gallery SET judul='$judul',gambar='$nama_g',isi='$isi',tanggal='$tanggal' where id='$id'")){
                    echo "<div class='alert alert-success'>Success!</div>";
                  }else{
                    echo "<div class='alert alert-danger'>Cek config!</div>";
                  }
                }else{
                  echo "<div class='alert alert-danger'>Gagal terupload!</div>";
                }
              }else{
                echo "<div class='alert alert-danger'>Compres gambar dulu!</div>";
              }
            }else{
              echo "<div class='alert alert-danger'>Harap lihat file!</div>";
            }
          }
          }elseif($_GET['menu']=="tambah_berita"){
          ?>
          <h1>Tambah berita</h1>
          <form action="?menu=tambah_berita" method="post" class="form-group" enctype="multipart/form-data">
            <label for="judul">Judul</label>
            <input type="text" placeholder="Judul..." class="form-control" name="judul" id="judul"><br>
            <label for="file">Gambar titile</label><br>
            <input type="file" name="file" id="file"><br><br>
            <label for="isi">Isi</label>
            <textarea class="ckeditor" name="isi" id="ckedtor" alt></textarea><br>
            <label for="author">Author</label>
            <input type="text" placeholder="Author" class="form-control" name="author" id="author"><br>
            <label for="konten">Konten</label>
            <input type="text" placeholder="Konten" class="form-control" name="konten" id="konten"><br>
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
          </form>
          <?php
          $judul=htmlentities(mysqli_real_escape_string($conn,$_POST['judul']));
          $isi=mysqli_real_escape_string($conn,$_POST['isi']);
          $konten=htmlentities(mysqli_real_escape_string($conn,$_POST['konten']));
          $author=htmlentities(mysqli_real_escape_string($conn,$_POST['author']));
          $tanggal=date("Y-m-d H:i:s");
          $rep_isi=str_replace("alert","",$isi);
          //end
          $nama_g=mysqli_real_escape_string($conn,$_FILES['file']['name']);
          $type_g=$_FILES['file']['type'];
          $ukuran_g=$_FILES['file']['size'];
          $tmp_g=$_FILES['file']['tmp_name'];
          $tempat_g="../berita/".$nama_g;
          $target_file_g="berita/".basename($nama_g);
          $type_file_g=pathinfo($target_file_g,PATHINFO_EXTENSION);
          if($_POST['submit']){
            if($type_file_g=="jpeg"||$type_file_g=="jpg"||$type_file_g=="gif"||$type_file_g=="png"||$type_file_g=="JPEG"||$type_file_g=="JPG"||$type_file_g=="GIF"||$type_file_g=="PNG"){
              if($ukuran_g<2097152){
                if(move_uploaded_file($tmp_g,$tempat_g)){
                  if(mysqli_query($conn,"INSERT INTO berita(tanggal,judul,file,isi,author,konten) values('$tanggal','$judul','$nama_g','$rep_isi','$author','$konten')")){
                    echo "<div class='alert alert-success'>Success!</div>";
                  }else{
                    echo "<div class='alert alert-danger'>Cek config!</div>";
                  }
                }else{
                  echo "<div class='alert alert-danger'>Gagal terupload!</div>";
                }
              }else{
                echo "<div class='alert alert-danger'>Compres gambar dulu!</div>";
              }
            }else{
              echo "<div class='alert alert-danger'>Harap lihat file!</div>";
            }
          }
          }elseif($_GET['menu']=="lihat_berita"){
            $no=1;
            $q_tampilberita=mysqli_query($conn,"SELECT * FROM berita order by id DESC");
          ?>
          <h1>Lihat berita</h1>
          <table class="table table-boarded">
            <thead>
              <tr>
                <th width="50px">No</th>
                <th width="600px">Judul</th>
                <th width="300px">Author</th>
                <th width="250px">Setting</th>
              </tr>
            </thead>
            <tbody>
            <?php
            while($cok=mysqli_fetch_array($q_tampilberita)){
            ?>
            <tr>
              <td><?php echo $no++; ?></td>
              <td><?php echo $cok['judul']; ?></td>
              <td><?php echo $cok['author']; ?></td>
              <td><a href="?menu=edit_berita&id=<?php echo $cok['id']; ?>" class="btn btn-warning">Edit</a> <a href="?menu=lihat_berita&delet=delete_berita&id=<?php echo $cok['id']; ?>" class="btn btn-danger">Delete</a></td>
            </tr>
            <?php
            }
            ?>
            </tbody>
          </table>
          <?php
            if($_GET['delet']=="delete_berita"){
              if($_GET['id']){
                $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
                $q_delet="DELETE FROM berita where id='$id'";
                if(mysqli_query($conn,$q_delet)){
                  echo "<div class='alert alert-success'>Success!</div>";
                  echo "
                  <script>
                  setTimeout(
                        function(){
                          window.location = '?menu=lihat_berita'
                        },
                        2000);
                  </script>
                  ";
                }else{
                  echo "<div class='alert alert-danger'>Cek config!</div>";
                }
              }else{
                echo "<div class='alert alert-warning'>Data tidak ditemukan</div>
                <script>
                setTimeout(
                      function(){
                        window.location = '?menu=lihat_berita'
                      },
                      2000);
                </script>
                ";
              }
            }
          }elseif ($_GET['menu']=="edit_berita") {
            if($_GET['id']){
              $id=htmlentities(mysqli_real_escape_string($conn,$_GET['id']));
          ?>
          <h1>Lihat berita</h1>
          <form action="?menu=edit_berita&id=<?php echo $id; ?>" method="post" class="form-group" enctype="multipart/form-data">
            <label for="judul">Judul</label>
            <input type="text" placeholder="Judul..." class="form-control" name="judul" id="judul"><br>
            <label for="file">Gambar titile</label><br>
            <input type="file" name="file" id="file"><br><br>
            <label for="isi">Isi</label>
            <textarea class="ckeditor" name="isi" id="ckedtor" alt></textarea><br>
            <label for="author">Author</label>
            <input type="text" placeholder="Author" class="form-control" name="author" id="author"><br>
            <label for="konten">Konten</label>
            <input type="text" placeholder="Konten" class="form-control" name="konten" id="konten"><br>
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
          </form>
          <?php
          $judul=htmlentities(mysqli_real_escape_string($conn,$_POST['judul']));
          $isi=mysqli_real_escape_string($conn,$_POST['isi']);
          $konten=htmlentities(mysqli_real_escape_string($conn,$_POST['konten']));
          $author=htmlentities(mysqli_real_escape_string($conn,$_POST['author']));
          $tanggal=date("Y-m-d H:i:s");
          $rep_isi=str_replace("alert","",$isi);
          //end
          $nama_g=mysqli_real_escape_string($conn,$_FILES['file']['name']);
          $type_g=$_FILES['file']['type'];
          $ukuran_g=$_FILES['file']['size'];
          $tmp_g=$_FILES['file']['tmp_name'];
          $tempat_g="../berita/".$nama_g;
          $target_file_g="berita/".basename($nama_g);
          $type_file_g=pathinfo($target_file_g,PATHINFO_EXTENSION);
          if($_POST['submit']){
            if($type_file_g=="jpeg"||$type_file_g=="jpg"||$type_file_g=="gif"||$type_file_g=="png"||$type_file_g=="JPEG"||$type_file_g=="JPG"||$type_file_g=="GIF"||$type_file_g=="PNG"){
              if($ukuran_g<2097152){
                if(move_uploaded_file($tmp_g,$tempat_g)){
                  if(mysqli_query($conn,"UPDATE berita set tanggal='$tanggal',judul='$judul',file='$nama_g',isi='$rep_isi',author='$author',konten='$konten' where id='$id'")){
                    echo "<div class='alert alert-success'>Success!</div>";
                  }else{
                    echo "<div class='alert alert-danger'>Cek config!</div>";
                  }
                }else{
                  echo "<div class='alert alert-danger'>Gagal terupload!</div>";
                }
              }else{
                echo "<div class='alert alert-danger'>Compres gambar dulu!</div>";
              }
            }else{
              echo "<div class='alert alert-danger'>Harap lihat file!</div>";
            }
            }
          }else{
            echo "<div class='alert alert-warning'>Data tidak ditemukan</div>
            <script>
            setTimeout(
                  function(){
                    window.location = '?menu=lihat_berita'
                  },
                  2000);
            </script>
            ";
          }
          }elseif($_GET['menu']=="lihat_user"){
            $no=1;
            $q_user=mysqli_query($conn,"SELECT * FROM admine");
          ?>
          <h1>Lihat user</h1>
          <table class="table table-boarded">
            <thead>
              <tr>
                <th width="60px">No</th>
                <th>Username</th>
                <th>Password</th>
                <th>Setting</th>
              </tr>
            </thead>
            <tbody>
              <tbody>
              <?php
              $wkw=['*','**','***','****','*****','******','*******','********','*********','**********'];
              $pass_l=rand('0,10');
              while($cok=mysqli_fetch_array($q_user)){
              ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlentities($cok['username']); ?></td>
                <td><?php echo $wkw[rand('0','10')]; ?></td>
                <td><a href="?menu=lihat_user&delet=delete_user&id=<?php echo $cok['id'];  ?>" class="btn btn-danger">Delete</a></td>
              </tr>
              <?php
              }
              if($_GET['delet']=="delete_user"){
                if($_GET['id']){
                  $id=mysqli_real_escape_string($conn,$_GET['id']);
                  if(mysqli_query($conn,"DELETE FROM admine where id='$id'")){
                    echo "<div class='alert alert-success'>Success delete admin!</div>
                    <script>
                    setTimeout(
                          function(){
                            window.location = '?menu=lihat_user'
                          },
                          2000);
                    </script>
                    ";
                  }else{
                    echo "<div class='alert alert-danger'>Cek config!</div>";
                  }
                }else{
                  echo "<div class='alert alert-warning'>Data tidak ditemukan</div>
                  <script>
                  setTimeout(
                        function(){
                          window.location = '?menu=lihat_user'
                        },
                        2000);
                  </script>";
                }
              }
              ?>
            </tbody>
          </table>
          <?php
          }
          ?>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; ICWR-TECH 2020</span><br><br>
            <span>Template by SB Admin 2</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="?m=out">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../asset/vendor/jquery/jquery.min.js"></script>
  <script src="../asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../asset/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../asset/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../asset/vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../asset/js/demo/chart-area-demo.js"></script>
  <script src="../asset/js/demo/chart-pie-demo.js"></script>

</body>

</html>
